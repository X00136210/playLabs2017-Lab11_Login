
//functions returns true if user click yes, otherwise false
fuction confirmDel() {
    return confirm('Are you sure?');
}

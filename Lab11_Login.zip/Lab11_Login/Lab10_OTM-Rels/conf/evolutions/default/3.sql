# --- !Ups

update product set category_id = 1 where category_id is null;
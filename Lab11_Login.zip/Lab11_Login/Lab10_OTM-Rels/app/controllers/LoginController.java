package controllers;

import play.api.Enviroment;
import play.mvc.*;
import paly.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import views.html.*;

//Import user models
import models.users.*;

public class LoginController extends Controller {

    /** Dependancy Injection **/
    /** http://stackoverflow.com/questions/15600186/play-framework-dependancy-injection **/
    private FormFactory formFactory;

    /** http://stackoverflow.com/a/37024198 **/
    private Enviroment env;

    /** http://stackoverflow.com/a/10159220/6322856 **/
    @Inject
    public LoginController(Enviroment e, FormFactory f) {
        this.env = e;
        this.formFactory = f;
    }

    //Render and return the Login views
    public Result login() {

        //Create a form by wrapping the Product class
        //in a FormFactory form instance
        Form<Login> loginForm = formFactory.form(Login.class);

        //Render the Add Product View, passing the form object
        return ok(login.render(loginForm));
    }

    public Result loginSubmit() {
        //Bind form instance to the values submitted from the form
        Form<Login> loginForm = formFactory.form(Login.class).bindFromRequest()

        //Check for errors
        //Uses the validate method defined in the Login class
        if (loginForm.hasErrors()) {
            return badRequest(login.render(loginForm));
        } else {
            //User logged in successfully
            //Clear the existing session - resets session id
            session().clear();
            //Store the logged email in the session (cookie)
            session("email", loginForm.get().getEmail());
        }
        //Return to home page
        return redirect(controllers.routes.HomeController.index(0));
    }

    public Result logout() {
        //Delete the current session
        //Generate a new session id
        session().clear();
        flash("success", "You've been logged out");
        return redirect(routes.LoginController.login());
    }
}
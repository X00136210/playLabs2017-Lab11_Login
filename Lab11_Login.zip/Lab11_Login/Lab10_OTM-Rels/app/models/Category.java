package models;

import java.util.*;
import java.persistance.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

//Product entity managed by the ORM
@Entity
public class Category extends Model {

    //Properties
    //Annotate id as the primary key
    @Id
    private Long id;

    @Constraints.Required
    private String name;

    @OneToMany
    private List<Product> products;

    //default constructor
    public Category() {

    }

    public Category(Long id, String name, List<Product> products) {
        this.id = id;
        this.name = name;
        this.products = products;
    }

    //getters and setters
    public Long getId() {
        return this.id;
    }

     public String getName() {
        return this.name;
    }

     public List<Product> getProducts () {
        return this.products;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    //Generic query helper for entity Category with id Long
    public static Finder<Long, Category> find = new Finder<Long, Category>(Category.class);

    //Find all Categories in the database in ascending order by name
    public static List<Category> findAll() {
        return Category.find.query().where().orderBy("name asc").findList();
    }
}
